//const express = require('express'); 
//const app = express(); 

//let musicas = [
 //       {id: 1,
 //       nome: "musica1"},
//
 //       {id: 2,
//        nome: "musica2"},
//]


//app.use(express());  
//app.get('/musicas', (req, res) =>{ 
 //   res.json(musicas);
//});

//app.listen(3000,()=> {
//    console.log('Servidor rodando na porta 3000')
//});


//atividade 1
const express = require('express'); 
const app = express(); 

let musicas = [{"id": 1, "nome": "beija flor"}, 
               {"id": 2, "nome": "4 cadeiras"},
               {"id": 3, "nome": "poesia acustica2"}
];

app.get('/musica/:id', (req, res) => {
    const { id } = req.params; // Extrai o parâmetro 'id' da rota
    const musica = musicas.find(m => m.id === parseInt(id)); // Busca a música pelo ID
            
    if (musica) {
        res.json(musica); // Retorna a música encontrada
    } else {
        res.status(404).json({ mensagem: "Música não encontrada" }); // Retorna erro 404
    }
});

//atividade 2
app.get('/musicanome/:id', (req, res) => {
    const {id} = req.params;
    const musicanome = musicas.find(m => m.id === parseInt(id));

 if (musicanome) {
        res.json({ nome: musicanome.nome }); // Retorna apenas o nome da música
    } 
 
else {
    res.status(404).json({ mensagem: "Música não encontrada" }); // Retorna erro 404
    }
});


//atividade 3



//atividaade 1 class
let frase = [{"frase": "Olá mundo"}]
app.get('/hello', (req, res) => {
    const {frases} = req.params;
    if (hello) {
        res.json({frase: hello.frase});
    }
    else {
        res.status(404).json({ mensagem: "Música não encontrada" }); // Retorna erro 404
        }

});

app.listen(3000,()=> {
    console.log('Servidor rodando na porta 3000')
});